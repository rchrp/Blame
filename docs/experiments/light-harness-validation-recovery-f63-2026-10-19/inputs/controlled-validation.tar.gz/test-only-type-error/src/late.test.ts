import {test,expect} from 'vitest';import {value} from './value';const expected: number = "1";test('expected value',()=>expect(value).toBe(Number(expected)));
