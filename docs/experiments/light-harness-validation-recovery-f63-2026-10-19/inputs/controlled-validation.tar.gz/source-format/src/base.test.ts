import {test,expect} from 'vitest';import {value} from './value';test('production value',()=>expect(value).toBe(1));
