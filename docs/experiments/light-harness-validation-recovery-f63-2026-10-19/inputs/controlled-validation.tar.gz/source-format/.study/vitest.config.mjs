export default {"test":{"include":["src/base.test.ts","src/late.test.ts"],"maxWorkers":1,"fileParallelism":false,"cache":false}};
