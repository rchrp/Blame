import {value} from '../src/value';const typed:number=value;void typed;
