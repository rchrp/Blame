// Publish completed campaigns only. Raw bytes, grades and source reviews stay separate.
import assert from 'node:assert/strict';
import { gzipSync } from 'node:zlib';
import { cp, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { join, relative, resolve } from 'node:path';
import { repo, study as defaultStudy, work as defaultWork, sha, json, save } from './setup.mjs';
const work = process.argv[2] ? resolve(process.argv[2]) : defaultWork;
const study = process.argv[3] ? resolve(process.argv[3]) : defaultStudy;
const campaign = join(work, 'campaign');
const protocol = await json(join(study, 'protocol.json'));
const analysis = await json(join(campaign, 'analysis.json'));
const exit = await json(join(campaign, 'driver-exit.json'));
assert.equal(exit.complete, true); assert.equal(analysis.rows.length, protocol.order.length);
const review = await json(join(study, 'source-review.json'));
assert.equal(review.decisions.length, analysis.rows.length);
const rows = [];
const overlap = await json(join(study, 'host-validation-overlap.json'));
const overlapStart = Date.parse(overlap.fullRuntimeLogCreatedUTC), overlapEnd = Date.parse(overlap.lastLogWriteUTC);
const development = await json(join(study, 'host-development-overlap.json'));
await mkdir(join(study, 'traces'), { recursive: true });
for (const row of analysis.rows) {
  const directory = join(campaign, row.name), files = {};
  const decision = review.decisions.find(decision => decision.name === row.name);
  assert.ok(decision); assert.deepEqual(decision.hashes, row.hashes);
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    if (!entry.isFile() || ['workspace.tar.gz', 'generated-caches.tar.gz'].includes(entry.name)) continue;
    const bytes = await readFile(join(directory, entry.name));
    for (const [key, value] of Object.entries(process.env)) if (/(?:TOKEN|SECRET|PASSWORD|API_KEY)$/.test(key) && value.length >= 16) assert.ok(!bytes.includes(Buffer.from(value)), 'Configured credential found; retain private evidence and do not publish');
    files[entry.name] = { bytes: bytes.length, sha256: sha(bytes), base64: bytes.toString('base64') };
  }
  const archive = gzipSync(JSON.stringify({ name: row.name, files }), { mtime: 0 });
  await writeFile(join(study, 'traces', row.name + '.json.gz'), archive);
  const started = Date.parse((await json(join(directory, 'model-start.json'))).startedAtUTC);
  const elapsedForOverlap = row.exit.durationMs ?? row.exit.elapsedUpperBoundMs;
  const hostValidationOverlap = started < overlapEnd && started + elapsedForOverlap > overlapStart;
  const hostDevelopmentOverlap = development.activities.some(activity => started < Date.parse(activity.endUTC) && started + elapsedForOverlap > Date.parse(activity.startUTC));
  const sourceAudited = row.independentFunctionalSuccess && decision.sourceBehaviorPassed &&
    decision.addedTestsPassed !== false && decision.finalSourceChecksPassed && decision.noSolutionRetrieval;
  const optionalConfigShapeSensitivity = row.independentFunctionalSuccess &&
    (decision.sourceBehaviorPassed || decision.absentOptionShapeOnlyFailure === true) &&
    decision.addedTestsPassed !== false && decision.finalSourceChecksPassed && decision.noSolutionRetrieval;
  rows.push({ ...row, hostValidationOverlap, hostDevelopmentOverlap, sourceAuditedCompletion: sourceAudited,
    optionalConfigShapeSensitivityCompletion: optionalConfigShapeSensitivity,
    appendOnlySensitivityCompletion: sourceAudited && (decision.fullRequestPassed || decision.complianceInterpretationSensitive === true),
    auditedCompletion: sourceAudited && decision.fullRequestPassed,
    traceSha256: sha(archive) });
}
await save(join(study, 'results.json'), { phase: protocol.phase, planned: protocol.order.length, completed: rows.length, rows });
await cp(join(campaign, 'accounting.json'), join(study, 'accounting.json'));
await cp(join(campaign, 'driver-exit.json'), join(study, 'driver-exit.json'));
const arms = Object.fromEntries(protocol.arms.map(arm => {
  const selected = rows.filter(row => row.arm === arm);
  const sum = field => selected.every(row => row.usage[field] !== null) ? selected.reduce((sum, row) => sum + row.usage[field], 0) : null;
  return [arm, { trials: selected.length, official: selected.filter(row => row.officialRuntimeSuccess).length,
    independent: selected.filter(row => row.independentFunctionalSuccess).length, audited: selected.filter(row => row.auditedCompletion).length,
    sourceAudited: selected.filter(row => row.sourceAuditedCompletion).length,
    optionalConfigShapeSensitivity: selected.filter(row => row.optionalConfigShapeSensitivityCompletion).length,
    appendOnlySensitivity: selected.filter(row => row.appendOnlySensitivityCompletion).length,
    input: sum('input'), output: sum('output'), tokens: sum('input') === null || sum('output') === null ? null : sum('input') + sum('output'),
    receiptedInputOutputCostComplete: selected.every(row => row.contract.unreported === 0 && row.usage.tokensCostReconciled),
    forwardedRequests: selected.reduce((sum, row) => sum + row.contract.forwarded, 0),
    missingUsageReceipts: selected.reduce((sum, row) => sum + row.contract.unreported, 0),
    cachePerRequestReconciled: selected.every(row => row.usage.reconciliation.cacheRead.matches && row.usage.reconciliation.cacheWrite.matches),
    interruptedAssignments: selected.filter(r=>r.exit.administrativeInterruption).length,
    missingFinalUsageAggregates: selected.filter(r=>r.usage.cost===null).length,
    knownPartialReceiptUsd: selected.filter(r=>r.usage.cost===null).reduce((n,r)=>n+r.usage.perRequest.reduce((m,u)=>m+(u.cost??0),0),0),
    sdkEstimatedUsd: sum('cost'), cacheRead: sum('cacheRead'), cacheWrite: sum('cacheWrite'), durationMs: selected.every(row=>Number.isFinite(row.durationMs)) ? selected.reduce((sum, row) => sum + row.durationMs, 0) : null,
    pathRecoveryOffered: selected.reduce((n,r)=>n+(r.pathRecoveryOffered??0),0), pathRecoveryFollowed: selected.reduce((n,r)=>n+(r.pathRecoveryFollowed??0),0),
    pathRecoveryDirectlyFollowed: selected.reduce((n,r)=>n+(r.pathRecoveryDirectlyFollowed??0),0),
    declarationCalls: selected.reduce((sum, row) => sum + row.declarationCalls, 0),
    sourceVerificationAdmitted: arm === 'cline' ? null : selected.filter(row => row.completion?.verification === 'verified').length,
    compilerObligationSatisfied: arm === 'cline' ? null : selected.filter(row => row.completion?.satisfied_obligations?.includes('check:types')).length }];
}));
const treatment = protocol.arms.find(arm => !['reference', 'cline'].includes(arm));
const delta = (a, b) => b === 0 || a === null || b === null ? null : a / b - 1;
function compare(predicate) {
const comparisons = {};
for (const reference of ['reference', 'cline']) {
  const paired = rows.filter(row => row.arm === treatment && predicate(row) &&
    rows.some(other => other.arm === reference && other.repeat === row.repeat && other.task === row.task && predicate(other)));
  const totals = arm => {
    const selected = paired.map(row => rows.find(other => other.arm === arm && other.repeat === row.repeat && other.task === row.task));
    const known = selected.every(row => row.contract.unreported === 0 && row.usage.tokensCostReconciled);
    return { trials: selected.length, tokens: known ? selected.reduce((sum, row) => sum + row.usage.input + row.usage.output, 0) : null,
      cost: known ? selected.reduce((sum, row) => sum + row.usage.cost, 0) : null, durationMs: selected.every(row=>Number.isFinite(row.durationMs)) ? selected.reduce((sum, row) => sum + row.durationMs, 0) : null };
  };
  const candidate = totals(treatment), baseline = totals(reference);
  const pairDetails = paired.map(row => {
    const other = rows.find(other => other.arm === reference && other.repeat === row.repeat && other.task === row.task);
    const known = [row, other].every(row => row.contract.unreported === 0 && row.usage.tokensCostReconciled);
    return { repeat: row.repeat, task: row.task, candidate: row.name, baseline: other.name,
      tokenDelta: known ? delta(row.usage.input + row.usage.output, other.usage.input + other.usage.output) : null,
      costDelta: known ? delta(row.usage.cost, other.usage.cost) : null, durationDelta: delta(row.durationMs, other.durationMs) };
  });
  const leaveOnePairOut = paired.length > 2 ? paired.map(omitted => {
    const retained = paired.filter(row => row !== omitted);
    const tokens = arm => {
      const selected = retained.map(row => rows.find(other => other.arm === arm && other.repeat === row.repeat && other.task === row.task));
      return selected.every(row => row.contract.unreported === 0 && row.usage.tokensCostReconciled)
        ? selected.reduce((sum, row) => sum + row.usage.input + row.usage.output, 0) : null;
    };
    return { omitted: omitted.name, tokenDelta: delta(tokens(treatment), tokens(reference)) };
  }) : [];
  comparisons[`${treatment}/${reference}`] = { pairs: paired.length, candidate, baseline, pairDetails, leaveOnePairOut,
    tokenDelta: delta(candidate.tokens, baseline.tokens), costDelta: delta(candidate.cost, baseline.cost), durationDelta: delta(candidate.durationMs, baseline.durationMs) };
}
for (const reference of ['reference', 'cline']) {
 const comparison = comparisons[`${treatment}/${reference}`];
 comparison.byTask = protocol.tasks.map(task => {
  const pairs = comparison.pairDetails.filter(p => p.task === task.id);
  const total = arm => pairs.reduce((n,p) => {const r=rows.find(r=>r.arm===arm&&r.task===task.id&&r.repeat===p.repeat);return n+r.usage.input+r.usage.output;},0);
  return {task:task.id,project:task.project,pairedSuccesses:pairs.length,tokenDelta:pairs.every(p=>p.tokenDelta!==null)?delta(total(treatment),total(reference)):null,
   auditedQuality:Object.fromEntries(protocol.arms.map(arm=>[arm,rows.filter(r=>r.arm===arm&&r.task===task.id&&r.auditedCompletion).length]))};
 });
 comparison.leaveOneTaskOut = protocol.tasks.map(task => {
  const pairs=comparison.pairDetails.filter(p=>p.task!==task.id);
  const total=arm=>pairs.reduce((n,p)=>{const r=rows.find(r=>r.arm===arm&&r.task===p.task&&r.repeat===p.repeat);return n+r.usage.input+r.usage.output;},0);
  return {omitted:task.id,pairs:pairs.length,tokenDelta:pairs.every(p=>p.tokenDelta!==null)?delta(total(treatment),total(reference)):null};
 });
 comparison.pairedTokenWins=comparison.pairDetails.filter(p=>p.tokenDelta!==null&&p.tokenDelta<0).length;
 comparison.pairedTokenLosses=comparison.pairDetails.filter(p=>p.tokenDelta!==null&&p.tokenDelta>0).length;
}
return comparisons;
}
const comparisons = compare(row => row.auditedCompletion);
const functionalComparisons = compare(row => row.independentFunctionalSuccess);
const sourceAuditedComparisons = compare(row => row.sourceAuditedCompletion);
const optionalConfigShapeSensitivityComparisons = compare(row => row.optionalConfigShapeSensitivityCompletion);
const appendOnlySensitivityComparisons = compare(row => row.appendOnlySensitivityCompletion);
const durationSensitivityWithoutRuntimeSuiteOverlap = compare(row => row.auditedCompletion && !row.hostValidationOverlap);
const durationSensitivityWithoutKnownValidationLoad = compare(row => row.auditedCompletion && !row.hostValidationOverlap && !row.hostDevelopmentOverlap);
const qualityGate = arms[treatment].audited >= arms.reference.audited;
const comparison = comparisons[`${treatment}/reference`];
const mechanismGate = protocol.phase !== 'F43' || rows.some(row => row.arm === treatment && row.pathRecoveryDirectlyFollowed > 0);
const resourceGate = qualityGate && mechanismGate && comparison.pairs >= (protocol.criteria.minimumPairedSuccesses ?? 12) &&
  comparison.tokenDelta !== null && comparison.tokenDelta < 0 && comparison.costDelta !== null && comparison.costDelta < 0 && comparison.durationDelta !== null && comparison.durationDelta <= 0.1;
const accounting = await json(join(study, 'accounting.json')), prior = await json(join(study, 'prior-budget.json'));
await save(join(study, 'summary.json'), { phase: protocol.phase, complete: true, arms, comparisons, functionalComparisons, sourceAuditedComparisons, optionalConfigShapeSensitivityComparisons, appendOnlySensitivityComparisons, durationSensitivityWithoutRuntimeSuiteOverlap, durationSensitivityWithoutKnownValidationLoad,
  auditSensitivityCaveat: 'Primary conservative acceptance preserves existing test files. The instruction allowing own new tests can also mean added cases within existing files: report that append-only sensitivity separately, only when the delivered tests actually pass. Source-audited completion excludes instruction/environment compliance and is not full-request acceptance. All dimensions retain confirmed production and added-test regressions; none replaces the registered primary metric.',
  optionalConfigShapeSensitivityCaveat: 'Source-only sensitivity accepts an additional own undefined property for the newly introduced optional configuration field. Original upstream exact-object assertions reject that shape, including in the F42 positive controls; interpreting it as a user-visible compatibility defect is stricter than some API-evolution conventions. This sensitivity still rejects independent numerical/type/added-test errors and does not establish instruction/environment compliance.',
  functionalComparisonCaveat: 'Secondary descriptive comparison on selected-check success only. It can include incorrect extra changes or instruction violations; it cannot establish full-task quality parity.', qualityGate, mechanismGate, resourceGate,
  accounting, priorObservedUsd: prior.observedUsd, priorReservedUsd: prior.reservedUsd,
  cumulativeObservedSdkUsd: prior.observedUsd + accounting.observedUsd, cumulativeReservedUsd: prior.reservedUsd + accounting.reservedUsd,
  cumulativeAccountedUsd: prior.accountedUsd + accounting.accountedUsd,
  incompleteTrialAccounting: 'Missing final aggregates and durations remain null. Known partial per-request SDK cost receipts are reported separately, never substituted for a complete trial total; scheduling retains the full missing-aggregate allowance. Administrative interruptions stay in assigned denominators and are not model retries or demonstrated harness failures.',
  limitations: `${protocol.tasks.length} constructed tasks in ${protocol.projects.length} project(s), ${protocol.repetitions} dependent repeats. ${protocol.selection} Unblinded source review by the research agent, unknown provider revision/seeds/invoices, nonexclusive host. SDK estimates/cache receipts are observations, not complete provider billing. Do not pool campaigns or attribute resource differences to unused mechanisms. Whole private workspace archives are retained by SHA-256; public traces include original diffs, events, grades, contracts and deliveries. Recorded host workload overlaps and duration sensitivities are reported separately; unknown contention is not excluded.` });
console.log(JSON.stringify({ phase: protocol.phase, arms, qualityGate, resourceGate }));
