import assert from "node:assert/strict";
import test from "node:test";
import { mkdir, mkdtemp, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import {
  parseArguments,
  prepareWorkspace,
  readManifest,
} from "./corpus-utils.mjs";
import { scoreRun } from "./score-run.mjs";
import { scenarioChecks } from "./scenario-checks.mjs";
import { selectedScenarios } from "./select-scenarios.mjs";
import { writeCampaignReport } from "./report-corpus.mjs";

test("campaigns require explicit groups of at most ten scenarios", async () => {
  const { scenarios } = await readManifest();
  assert.throws(() => selectedScenarios(scenarios), /ten scenarios/u);
  assert.throws(
    () =>
      selectedScenarios(
        scenarios,
        scenarios
          .slice(0, 11)
          .map(({ id }) => id)
          .join(","),
      ),
    /ten scenarios/u,
  );
  assert.equal(
    selectedScenarios(
      scenarios,
      scenarios
        .slice(0, 10)
        .map(({ id }) => id)
        .join(","),
    ).length,
    10,
  );
});

test("behavior scoring rejects correct text in unreachable code", async () => {
  const root = await mkdtemp(join(tmpdir(), "blame-behavior-score-"));
  try {
    await mkdir(join(root, "src"));
    await writeFile(
      join(root, "src/project-label.ts"),
      'export function formatProjectLabel(name: string) { return "WRONG"; return `Project · ${name.trim()}`; }',
    );
    const checks = await scenarioChecks("symbol-function", root);
    assert.equal(
      checks.every(({ passed }) => passed),
      false,
    );
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("reports leave missing usage unknown instead of treating it as free", async () => {
  const root = await mkdtemp(join(tmpdir(), "blame-unknown-usage-"));
  try {
    await mkdir(join(root, "run"));
    await writeFile(
      join(root, "run/score.json"),
      JSON.stringify({
        scenario: "missing",
        qualityScore: 0,
        tokens: { input: null, output: null, cost: null },
      }),
    );
    const report = await writeCampaignReport(root);
    assert.equal(report.totalTokens.input, null);
    assert.equal(report.totalCost, null);
    assert.equal(report.missingUsageRuns, 1);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("defines twenty-five unique scored scenarios", async () => {
  const manifest = await readManifest();
  const identifiers = manifest.scenarios.map(({ id }) => id);
  assert.equal(identifiers.length, 25);
  assert.equal(new Set(identifiers).size, 25);
  for (const scenario of manifest.scenarios) {
    assert.ok(scenario.allowedPaths.length > 0);
    assert.ok(scenario.maxIterations > 0);
    assert.ok(scenario.timeoutSeconds > 0);
  }
});

test("registers deterministic checks for every scenario", async () => {
  const root = await mkdtemp(join(tmpdir(), "blame-checks-"));
  try {
    const workspace = join(root, "workspace");
    await prepareWorkspace(workspace, "check-registration");
    const manifest = await readManifest();
    for (const scenario of manifest.scenarios) {
      const checks = await scenarioChecks(scenario.id, workspace);
      assert.ok(checks.length > 0, scenario.id);
    }
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("accepts the pnpm argument separator", () => {
  const options = parseArguments(["--", "--label", "baseline"]);
  assert.equal(options.get("label"), "baseline");
});

test("materializes the same scenario at one reproducible revision", async () => {
  const root = await mkdtemp(join(tmpdir(), "blame-revision-"));
  try {
    const first = await prepareWorkspace(join(root, "first"), "tsx-hybrid");
    const second = await prepareWorkspace(join(root, "second"), "tsx-hybrid");
    assert.equal(first, second);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("materializes and scores an isolated workspace", async () => {
  const root = await mkdtemp(join(tmpdir(), "blame-corpus-"));
  try {
    const workspace = join(root, "workspace");
    const runDirectory = join(root, "run");
    const manifest = await readManifest();
    const scenario = manifest.scenarios.find(
      ({ id }) => id === "symbol-function",
    );
    assert.ok(scenario);
    await prepareWorkspace(workspace, scenario.id);
    await mkdir(runDirectory);
    await writeFile(
      join(workspace, "src/project-label.ts"),
      "export function formatProjectLabel(name: string) {\n  return `Project · ${name.trim()}`;\n}\n",
      "utf8",
    );
    await mkdir(join(workspace, ".blame/logs"), { recursive: true });
    await writeFile(join(workspace, ".blame/logs/runtime.log"), "internal\n");
    await writeFile(join(runDirectory, "events.jsonl"), "", {
      encoding: "utf8",
      flag: "a",
    });
    await writeFile(
      join(runDirectory, "result.json"),
      `${JSON.stringify(successfulResult())}\n`,
      { encoding: "utf8", flag: "a" },
    );
    const score = await scoreRun(runDirectory, workspace, scenario);
    assert.equal(score.qualityScore, 100);
    assert.equal(score.formattingPassed, true);
    assert.deepEqual(score.changedPaths, ["src/project-label.ts"]);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("large creation scoring counts fields instead of prose occurrences", async () => {
  const root = await mkdtemp(join(tmpdir(), "blame-large-score-"));
  try {
    await mkdir(join(root, "src"));
    const entries = Array.from({ length: 120 }, (_, index) => {
      const sequence = String(index + 1).padStart(3, "0");
      return `{ id: "project-${sequence}", title: "Project ${sequence}", status: "published", description: "Project ${sequence} is published in the catalogue with additional readable detail." }`;
    });
    const source = `export type ProjectSeed = { id: string; title: string; status: "published"; description: string };\nexport const PROJECT_SEEDS: ProjectSeed[] = [\n${entries.join(",\n")}\n];\n`;
    await writeFile(join(root, "src/project-seed.ts"), source, "utf8");
    const checks = await scenarioChecks("large-create", root);
    assert.ok(checks.every(({ passed }) => passed));
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("accepts visible button text as an accessible name", async () => {
  const root = await mkdtemp(join(tmpdir(), "blame-a11y-score-"));
  try {
    await mkdir(join(root, "src"));
    await writeFile(
      join(root, "src/ProjectFilter.tsx"),
      '<label htmlFor="project-search">Search projects</label><input id="project-search" type="search" /><button type="button" aria-pressed={featuredOnly}>Featured only</button><span aria-live="polite">Results</span>',
      "utf8",
    );
    const checks = await scenarioChecks("filter-accessibility", root);
    assert.ok(checks.every(({ passed }) => passed));
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

function successfulResult() {
  return {
    durationMs: 1_000,
    harness: "blame",
    metrics: {
      editing: { blocked: 0, symbolOperations: 1 },
      navigation: { deduplicatedReads: 0, readCalls: 1, returnedBytes: 100 },
      tools: { calls: 3 },
    },
    status: "succeeded",
    taskId: "symbol-function",
    usage: { aggregateUsage: { totalInputTokens: 100, totalOutputTokens: 10 } },
    verified: true,
  };
}
