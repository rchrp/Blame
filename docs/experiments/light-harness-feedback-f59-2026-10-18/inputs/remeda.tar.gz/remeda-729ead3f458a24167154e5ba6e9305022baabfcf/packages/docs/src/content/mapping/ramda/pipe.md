---
category: Function
remeda: pipe
---
