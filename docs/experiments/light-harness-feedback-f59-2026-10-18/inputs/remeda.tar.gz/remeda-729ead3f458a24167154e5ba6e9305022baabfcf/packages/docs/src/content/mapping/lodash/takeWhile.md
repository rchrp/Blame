---
category: Array
remeda: takeWhile
---
