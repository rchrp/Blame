---
category: Logic
remeda: when
---
