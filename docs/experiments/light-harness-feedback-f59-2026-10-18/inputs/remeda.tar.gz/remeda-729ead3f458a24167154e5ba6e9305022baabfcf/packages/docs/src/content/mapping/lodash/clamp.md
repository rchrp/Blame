---
category: Number
remeda: clamp
---
