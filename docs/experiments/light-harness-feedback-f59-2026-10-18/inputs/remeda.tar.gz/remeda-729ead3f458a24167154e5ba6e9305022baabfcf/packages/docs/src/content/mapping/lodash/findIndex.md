---
category: Array
remeda: findIndex
---
