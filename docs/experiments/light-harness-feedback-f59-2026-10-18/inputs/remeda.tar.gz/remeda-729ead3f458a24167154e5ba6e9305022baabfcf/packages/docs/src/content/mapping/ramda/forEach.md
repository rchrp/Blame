---
category: List
remeda: forEach
---
