---
category: Object
remeda: objOf
---
