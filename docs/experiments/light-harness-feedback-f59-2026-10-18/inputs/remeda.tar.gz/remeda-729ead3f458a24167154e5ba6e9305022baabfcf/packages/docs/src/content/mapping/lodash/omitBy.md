---
category: Object
remeda: omitBy
---
