---
category: Function
remeda: constant
---
