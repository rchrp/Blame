---
category: Array
remeda: zipWith
---
