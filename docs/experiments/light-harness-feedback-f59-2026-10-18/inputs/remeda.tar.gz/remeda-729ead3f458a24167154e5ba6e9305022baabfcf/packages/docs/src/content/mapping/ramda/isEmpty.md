---
category: Logic
remeda: isEmpty
---
