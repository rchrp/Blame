---
category: Lang
remeda: isEmpty
---
