---
category: Array
remeda: dropLastWhile
---
