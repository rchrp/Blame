---
category: Object
remeda: forEachObj
---
