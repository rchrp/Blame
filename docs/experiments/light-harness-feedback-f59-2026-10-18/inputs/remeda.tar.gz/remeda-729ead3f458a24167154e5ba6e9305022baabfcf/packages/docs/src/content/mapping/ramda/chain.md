---
category: List
remeda: flatMap
---
