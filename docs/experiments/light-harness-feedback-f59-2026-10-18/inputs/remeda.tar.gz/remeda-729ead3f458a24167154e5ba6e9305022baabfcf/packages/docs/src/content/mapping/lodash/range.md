---
category: Util
remeda: range
---
