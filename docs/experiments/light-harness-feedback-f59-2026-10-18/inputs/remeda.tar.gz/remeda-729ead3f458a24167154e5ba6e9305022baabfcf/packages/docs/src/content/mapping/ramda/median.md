---
category: Math
remeda: median
---
