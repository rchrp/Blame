---
category: Array
remeda: fromEntries
---
