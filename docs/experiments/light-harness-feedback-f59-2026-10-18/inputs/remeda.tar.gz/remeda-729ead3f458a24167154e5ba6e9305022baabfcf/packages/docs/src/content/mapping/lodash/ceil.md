---
category: Math
remeda: ceil
---
