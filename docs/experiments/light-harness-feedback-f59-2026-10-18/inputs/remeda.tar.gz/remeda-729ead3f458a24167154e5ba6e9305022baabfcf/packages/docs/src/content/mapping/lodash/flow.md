---
category: Util
remeda: pipe
---
