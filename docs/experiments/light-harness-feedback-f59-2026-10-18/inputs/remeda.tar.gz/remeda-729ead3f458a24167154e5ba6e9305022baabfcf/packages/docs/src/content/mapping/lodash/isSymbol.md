---
category: Lang
remeda: isSymbol
---
