---
category: Array
remeda: sortedIndex
---
