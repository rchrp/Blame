---
category: Array
remeda: sortedLastIndexBy
---
