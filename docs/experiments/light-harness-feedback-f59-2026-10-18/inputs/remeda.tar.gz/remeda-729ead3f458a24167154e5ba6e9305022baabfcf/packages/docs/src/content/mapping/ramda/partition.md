---
category: List
remeda: partition
---
