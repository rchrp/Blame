---
category: Lang
remeda: isDeepEqual
---
