---
category: List
remeda: zipWith
---
