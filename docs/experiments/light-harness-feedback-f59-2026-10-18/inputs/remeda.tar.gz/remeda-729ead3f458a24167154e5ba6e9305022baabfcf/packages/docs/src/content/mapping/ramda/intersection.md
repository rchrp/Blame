---
category: Relation
remeda: intersection
---
