---
category: Array
remeda: sortedIndexBy
---
