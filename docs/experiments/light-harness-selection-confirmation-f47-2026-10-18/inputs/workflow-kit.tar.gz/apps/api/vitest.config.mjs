export default {test:{include:["src/**/*.test.ts"],maxWorkers:1,fileParallelism:false,cache:false}};
