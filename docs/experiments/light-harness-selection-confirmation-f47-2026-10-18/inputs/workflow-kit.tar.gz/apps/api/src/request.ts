import {createRequestContext, withCorrelation} from '../../../packages/request/src/index.ts';
import type {Headers, LogFields} from '../../../packages/request/src/index.ts';
export function handleRequest(headers: Headers, fallbackId: string, fields: LogFields = {}) {
 const context = createRequestContext(headers, fallbackId);
 return {status:200, headers:{'x-correlation-id':fallbackId}, body:{message:'ok', correlationId:context.correlationId}, log:withCorrelation(fields, fallbackId)};
}
