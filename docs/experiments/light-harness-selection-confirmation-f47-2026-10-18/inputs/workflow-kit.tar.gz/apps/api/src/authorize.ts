import {authenticate,AuthError} from '../../../packages/security/src/index.ts';
import type {Token} from '../../../packages/security/src/index.ts';
export function authorize(token: Token) { try{return {status:200,body:authenticate(token)};}catch(error){if(error instanceof AuthError)return {status:401,body:{message:error.message}};throw error;} }
