import {createCsvExporter} from '../../../packages/export/src/index.ts';
import type {Cell} from '../../../packages/export/src/index.ts';
export function exportReport(columns: readonly string[], rows: readonly (readonly Cell[])[]) { return {status:200,contentType:'text/csv',body:createCsvExporter(columns)(rows)}; }
