import {test,expect} from 'vitest';
import {handleRequest} from './request.ts';
import {exportReport} from './export.ts';
import {authorize} from './authorize.ts';
test('request response',()=>{expect(handleRequest({},'req')).toMatchObject({status:200,headers:{'x-correlation-id':'req'},body:{message:'ok',correlationId:'req'}});});
test('CSV response',()=>{expect(exportReport(['a'],[[1]])).toEqual({status:200,contentType:'text/csv',body:'a\n1'});});
test('authorization response',()=>{expect(authorize({subject:'user'})).toEqual({status:200,body:{subject:'user'}});expect(authorize({subject:''})).toMatchObject({status:401,body:{message:'Invalid token'}});});
