export default {test:{include:["packages/**/*.test.ts","apps/**/*.test.ts"],maxWorkers:1,fileParallelism:false,cache:false}};
