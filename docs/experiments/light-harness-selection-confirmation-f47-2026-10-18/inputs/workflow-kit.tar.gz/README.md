# Workflow kit

Small npm monorepo: request owns request context/log fields, export owns CSV contracts, security owns authentication policy; apps/api composes these packages. Package test scripts run from that package directory. Root regression checks run the original tests; delivered checks discover newly added tests. Root source typechecking excludes test files.
