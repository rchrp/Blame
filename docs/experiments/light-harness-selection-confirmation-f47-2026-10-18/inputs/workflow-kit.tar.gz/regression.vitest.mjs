export default {test:{include:["packages/*/src/original.test.ts","apps/api/src/original.test.ts"],maxWorkers:1,fileParallelism:false,cache:false}};
