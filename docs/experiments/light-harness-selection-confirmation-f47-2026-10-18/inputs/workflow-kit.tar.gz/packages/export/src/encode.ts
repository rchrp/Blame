export type Cell = string | number | boolean | null | undefined;
export function encodeCell(value: Cell, delimiter: string): string { const text = value == null ? '' : String(value); return text.includes(delimiter) ? '"' + text.replaceAll('"','""') + '"' : text; }
