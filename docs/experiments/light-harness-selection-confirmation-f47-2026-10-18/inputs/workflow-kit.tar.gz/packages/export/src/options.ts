export interface CsvOptions { delimiter?: string | undefined; newline?: string | undefined; includeHeader?: boolean | undefined }
export interface ResolvedCsvOptions { delimiter: string; newline: string; includeHeader: boolean }
export function resolveOptions(options: CsvOptions = {}): ResolvedCsvOptions { return {delimiter:options.delimiter ?? ',',newline:options.newline ?? '\n',includeHeader:options.includeHeader ?? true}; }
