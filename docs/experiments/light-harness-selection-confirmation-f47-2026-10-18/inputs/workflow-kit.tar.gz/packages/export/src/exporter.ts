import {resolveOptions} from './options.ts';
import type {CsvOptions} from './options.ts';
import {encodeCell} from './encode.ts';
import type {Cell} from './encode.ts';
export function createCsvExporter(columns: readonly string[], options: CsvOptions = {}) {
 const resolved = resolveOptions(options);
 return (rows: readonly (readonly Cell[])[]): string => {
  const lines = rows.map(row => row.map(cell => encodeCell(cell,resolved.delimiter)).join(resolved.delimiter));
  if(resolved.includeHeader) lines.unshift(columns.join(resolved.delimiter));
  return lines.join(resolved.newline);
 };
}
