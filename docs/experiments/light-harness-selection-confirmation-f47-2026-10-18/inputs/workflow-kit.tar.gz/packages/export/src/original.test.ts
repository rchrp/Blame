import {test,expect} from 'vitest';
import {createCsvExporter} from './index.ts';
test('default export and integer/boolean cells',()=>{expect(createCsvExporter(['name','value'])([['Ada',0],['Bo',false]])).toBe('name,value\nAda,0\nBo,false');});
