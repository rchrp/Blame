import {test,expect} from 'vitest';
import {createRequestContext,withCorrelation} from './index.ts';
test('fallback and immutable log enrichment',()=>{expect(createRequestContext({},'fallback')).toEqual({correlationId:'fallback'});const f={event:'request'};expect(withCorrelation(f,'abc')).toEqual({event:'request',correlationId:'abc'});expect(f).toEqual({event:'request'});});
