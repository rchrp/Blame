export type LogFields = Readonly<Record<string, unknown>>;
export function withCorrelation(fields: LogFields, correlationId: string): Record<string, unknown> { return {...fields, correlationId}; }
