export type Headers = Readonly<Record<string, string | readonly string[] | undefined>>;
export interface RequestContext { correlationId: string }
export function createRequestContext(_headers: Headers, fallbackId: string): RequestContext { return {correlationId: fallbackId}; }
