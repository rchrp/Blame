import type {Token} from './types.ts';
import {AuthError} from './errors.ts';
import {validSubject} from './policy.ts';
export function authenticate(token: Token) { if(!validSubject(token)) throw new AuthError('Invalid token'); return {subject:token.subject}; }
