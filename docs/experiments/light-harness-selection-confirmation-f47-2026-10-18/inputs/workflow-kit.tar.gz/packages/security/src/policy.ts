import type {Token} from './types.ts';
export function validSubject(token: Token): boolean { return token.subject.length > 0; }
