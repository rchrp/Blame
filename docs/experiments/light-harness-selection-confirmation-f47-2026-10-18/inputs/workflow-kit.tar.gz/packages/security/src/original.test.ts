import {test,expect} from 'vitest';
import {authenticate,AuthError} from './index.ts';
test('valid and empty subjects',()=>{expect(authenticate({subject:'user'})).toEqual({subject:'user'});expect(()=>authenticate({subject:''})).toThrow(AuthError);});
