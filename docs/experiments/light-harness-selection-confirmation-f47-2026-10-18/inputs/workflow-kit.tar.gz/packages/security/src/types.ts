export interface Token { subject: string; expiresAt?: number | undefined }
