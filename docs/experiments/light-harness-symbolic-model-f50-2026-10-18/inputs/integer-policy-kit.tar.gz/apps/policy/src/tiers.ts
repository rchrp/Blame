import {lowerTierUnits,upperTierUnits} from '../../../packages/tiers/src/index.ts';
export function quoteTierUsage(first:number,last:number,boundary:number,lowerRate:number,upperRate:number) {
 const lower=lowerTierUnits(first,last,boundary);
 const upper=upperTierUnits(first,last,boundary);
 return {lower,upper,totalCost:lower*lowerRate};
}
