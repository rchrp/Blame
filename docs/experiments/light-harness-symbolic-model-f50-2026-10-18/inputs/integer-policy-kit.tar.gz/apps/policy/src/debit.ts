import {approveDebit} from '../../../packages/credit/src/index.ts';
export function quoteDebit(balance:number,reserved:number,limit:number,requested:number) {
 const approved=approveDebit(balance,reserved,limit,requested);
 return {approved,remaining:limit-approved,denied:requested-approved};
}
