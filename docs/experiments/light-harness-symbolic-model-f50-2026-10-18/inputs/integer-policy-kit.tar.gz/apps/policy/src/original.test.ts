import {test,expect} from 'vitest';
import {quoteDebit} from './debit.ts';
import {quoteTierUsage} from './tiers.ts';
import {inspectShiftedWindow} from './windows.ts';
test('public consumer basic shapes',()=>{expect(quoteDebit(20,10,100,40)).toMatchObject({approved:40,denied:0});expect(quoteTierUsage(3,2,1,1,2)).toEqual({lower:0,upper:0,totalCost:0});expect(inspectShiftedWindow(1,8,3,6,0,2)).toEqual({overlap:3,qualifies:true});});
