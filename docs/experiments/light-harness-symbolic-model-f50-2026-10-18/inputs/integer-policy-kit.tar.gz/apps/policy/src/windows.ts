import {overlapLength,overlapsAtLeast} from '../../../packages/windows/src/index.ts';
export function inspectShiftedWindow(startA:number,endA:number,startB:number,endB:number,offset:number,minimum:number) {
 return {overlap:overlapLength(startA,endA,startB+offset,endB),qualifies:overlapsAtLeast(startA,endA,startB+offset,endB,minimum)};
}
