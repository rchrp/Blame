export function tierCost(lowerUnits:number,upperUnits:number,lowerRate:number,upperRate:number):number {
 return lowerUnits*lowerRate+upperUnits*upperRate;
}
