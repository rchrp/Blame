import {test,expect} from 'vitest';
import {lowerTierUnits,upperTierUnits,tierCost} from './index.ts';
test('empty and separate tier ranges',()=>{expect(lowerTierUnits(4,2,3)).toBe(0);expect(upperTierUnits(4,2,3)).toBe(0);expect(lowerTierUnits(5,9,2)).toBe(0);expect(upperTierUnits(5,9,2)).toBe(5);expect(tierCost(2,3,1,2)).toBe(8);});
