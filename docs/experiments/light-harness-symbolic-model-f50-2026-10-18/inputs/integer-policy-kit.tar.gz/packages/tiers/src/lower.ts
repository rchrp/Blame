export function lowerTierUnits(first:number,last:number,boundary:number):number {
 if(first>last)return 0;
 const lowerEnd=last<boundary?last:boundary;
 return lowerEnd>=first?lowerEnd-first:0;
}
