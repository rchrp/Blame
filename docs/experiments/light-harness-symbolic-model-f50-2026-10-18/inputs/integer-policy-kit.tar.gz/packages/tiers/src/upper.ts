export function upperTierUnits(first:number,last:number,boundary:number):number {
 if(first>last)return 0;
 const upperStart=first>boundary?first:boundary;
 return last>=upperStart?last-upperStart+1:0;
}
