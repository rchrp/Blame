import {overlapLength} from './overlap.ts';
export function overlapsAtLeast(startA:number,endA:number,startB:number,endB:number,minimum:number):boolean {
 return overlapLength(startA,endA,startB,endB)>minimum;
}
