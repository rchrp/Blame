export function overlapLength(startA:number,endA:number,startB:number,endB:number):number {
 if(startA<0||startB<0)return 0;
 if(endA<=startA||endB<=startB)return 0;
 const start=startA>startB?startA:startB;
 const end=endA<endB?endA:endB;
 return end>start?end-start:0;
}
