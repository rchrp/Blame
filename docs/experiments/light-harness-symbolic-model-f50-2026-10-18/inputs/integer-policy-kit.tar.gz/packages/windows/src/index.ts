export {overlapLength} from './overlap.ts';
export {overlapsAtLeast} from './qualifies.ts';
