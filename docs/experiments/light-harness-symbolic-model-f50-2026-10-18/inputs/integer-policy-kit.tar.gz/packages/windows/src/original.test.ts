import {test,expect} from 'vitest';
import {overlapLength,overlapsAtLeast} from './index.ts';
test('positive overlap and clearly separated intervals',()=>{expect(overlapLength(1,8,3,6)).toBe(3);expect(overlapLength(1,2,3,4)).toBe(0);expect(overlapsAtLeast(1,8,3,6,2)).toBe(true);});
