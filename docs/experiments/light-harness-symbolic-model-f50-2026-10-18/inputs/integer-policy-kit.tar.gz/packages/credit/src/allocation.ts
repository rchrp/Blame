import {availableCredit} from './remainder.ts';
export function approveDebit(balance:number,reserved:number,limit:number,requested:number):number {
 const available=availableCredit(balance,reserved,limit);
 return requested<available?requested:available;
}
