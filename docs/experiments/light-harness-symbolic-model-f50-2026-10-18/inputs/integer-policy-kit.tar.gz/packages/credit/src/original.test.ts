import {test,expect} from 'vitest';
import {availableCredit,approveDebit} from './index.ts';
test('ordinary positive credit reservation',()=>{expect(availableCredit(20,10,100)).toBe(70);expect(approveDebit(20,10,100,40)).toBe(40);});
