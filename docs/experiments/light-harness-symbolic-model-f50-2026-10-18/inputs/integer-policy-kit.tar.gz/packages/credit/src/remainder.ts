export function availableCredit(balance:number,reserved:number,limit:number):number {
 const remainder=limit-balance-reserved;
 return remainder;
}
