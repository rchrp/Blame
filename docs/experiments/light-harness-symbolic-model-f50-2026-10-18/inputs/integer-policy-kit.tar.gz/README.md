# Integer policy kit

Small npm monorepo: credit, tiers and windows expose pure integer policies; apps/policy composes them. Each package test script runs from its own directory. Root regression checks run the original tests, delivered checks discover new regression files and root source compilation excludes tests.
